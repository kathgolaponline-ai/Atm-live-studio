# ATM LIVE STUDIO

Professional multi-camera web broadcast starter: eight mobile camera inputs, private admin room, program switching, public web player, and YouTube RTMP deployment path.

## Important: this is a deployable project, not a hosted website
The project must be deployed to HTTPS and connected to a LiveKit Cloud (or self-hosted LiveKit) project. Camera access requires HTTPS (localhost is allowed for development). Remote phones need internet access. A normal static GitHub Pages deployment cannot run the private token API or WebRTC media server.

## 1. Requirements
- Node.js 20+
- LiveKit Cloud project (recommended) or a correctly configured LiveKit server
- A hosting provider that supports Next.js server routes (Vercel, Render, Railway, etc.)
- Modern phones with Chrome/Safari camera permission

## 2. Configure LiveKit
Create a project at https://cloud.livekit.io/ and copy:
- WebSocket URL (`wss://...`)
- API key
- API secret

Copy `.env.example` to `.env.local` and fill in:
- `NEXT_PUBLIC_LIVEKIT_URL`
- `LIVEKIT_API_KEY`
- `LIVEKIT_API_SECRET`
- `SESSION_SECRET` (generate a long random value)
- `ADMIN_USERNAME`
- `ADMIN_PASSWORD`

The requested initial username was `Atm1003`. Set it in the server environment if you still want it. Choose a new, unique password before publishing; do not reuse a password that has appeared in chat. The application never places credentials in browser code. For a production deployment, use a strong unique password and enable hosting-provider secret management.

## 3. Run locally
```bash
npm install
cp .env.example .env.local
npm run dev
```
Open http://localhost:3000. For mobile camera testing from other devices, deploy to HTTPS; localhost on the computer is not reachable from a remote phone.

## 4. Connect mobile cameras
1. Sign in at `/admin/login`.
2. In the admin room, copy a camera link (for example `/camera/cam-1`).
3. Send/open that link on the phone assigned to CAM 1.
4. Tap Connect Camera and allow camera permission.
5. Repeat for CAM 2 through CAM 8.
6. Select a connected tile and press TAKE TO PROGRAM.
7. Open `/watch` on another device to watch the program track.

The eight camera slots use fixed identities `cam-1` through `cam-8`. Use one active phone per slot. Each camera publishes a single video feed. Microphone/audio mixing is intentionally not enabled in this starter to avoid feedback; production audio routing should be added deliberately.

## 5. Website + YouTube Live
The `/watch` page is the website viewing destination. The YouTube control is intentionally marked setup-required: to send a real RTMP stream, configure LiveKit Egress for your LiveKit deployment and add the YouTube RTMP server URL and stream key as server-side secrets. Then implement/enable an Egress start/stop route using the Egress service available for your LiveKit deployment. Egress is a separately deployed media service in self-hosted installations; LiveKit Cloud plan/feature availability may vary. Never expose the YouTube stream key to the browser.

Useful official documentation:
- Token grants: https://docs.livekit.io/home/server/generating-tokens/
- Client SDK: https://docs.livekit.io/reference/client-sdk-js/
- Egress: https://docs.livekit.io/transport/media/ingress-egress/egress/
- Egress outputs: https://docs.livekit.io/transport/media/ingress-egress/egress/outputs/

## 6. Production hardening checklist
- Replace the initial admin password before going live.
- Use a long random `SESSION_SECRET`.
- Add rate limiting to `/api/auth/login`.
- Add a per-camera pairing PIN or one-time invite token before public deployment. Camera links in this starter are slot links and should be treated as private.
- Add CSRF/origin protections and monitoring.
- Test actual network upload bandwidth and device thermal limits. Eight 1080p feeds require substantial upstream bandwidth and may be reduced by adaptive streaming.
- A 1080p output is the target canvas size; the actual source quality depends on the phone camera, network, browser, and LiveKit subscription/encoding settings.

## Current implementation boundaries
- Camera connection and program video routing use LiveKit WebRTC.
- Admin can preview and take connected camera feeds to a shared `program` video track.
- Public viewers subscribe to that program track.
- YouTube RTMP egress requires the separate Egress configuration described above; the visible control room clearly identifies it as not yet enabled rather than pretending it is streaming.
