import { SignJWT, jwtVerify } from "jose";
import { cookies } from "next/headers";
const secret = () => {
  const value = process.env.SESSION_SECRET;
  if (!value || value.length < 32) throw new Error("SESSION_SECRET must be at least 32 characters.");
  return new TextEncoder().encode(value);
};
export async function createSession(username:string) {
  const token = await new SignJWT({sub:username,role:"admin"}).setProtectedHeader({alg:"HS256"}).setIssuedAt().setExpirationTime("8h").sign(secret());
  const jar = await cookies();
  jar.set("atm_admin",token,{httpOnly:true,secure:process.env.NODE_ENV==="production",sameSite:"strict",path:"/",maxAge:8*60*60});
}
export async function isAdmin() {
  try { const jar=await cookies(); const token=jar.get("atm_admin")?.value; if(!token)return false; const {payload}=await jwtVerify(token,secret()); return payload.role==="admin" && payload.sub===process.env.ADMIN_USERNAME; } catch { return false; }
}
export async function clearSession(){const jar=await cookies();jar.set("atm_admin","",{httpOnly:true,secure:process.env.NODE_ENV==="production",sameSite:"strict",path:"/",maxAge:0});}
