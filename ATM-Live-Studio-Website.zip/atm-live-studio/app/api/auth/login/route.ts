import {NextRequest,NextResponse} from "next/server";
import {createSession} from "@/lib/auth";
export async function POST(req:NextRequest){
 try{
  const {username,password}=await req.json();
  if(!process.env.ADMIN_USERNAME||!process.env.ADMIN_PASSWORD) return NextResponse.json({error:"Admin credentials are not configured."},{status:503});
  if(username!==process.env.ADMIN_USERNAME || password!==process.env.ADMIN_PASSWORD) return NextResponse.json({error:"Invalid administrator credentials."},{status:401});
  await createSession(username);
  return NextResponse.json({ok:true});
 }catch{return NextResponse.json({error:"Unable to sign in."},{status:400});}
}
