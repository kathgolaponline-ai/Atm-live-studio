import {NextRequest,NextResponse} from "next/server";
import {AccessToken} from "livekit-server-sdk";
import {isAdmin} from "@/lib/auth";
export const runtime="nodejs";
export async function POST(req:NextRequest){
 try{
  const {role,cameraId}=await req.json();
  if(!process.env.LIVEKIT_API_KEY||!process.env.LIVEKIT_API_SECRET||!process.env.NEXT_PUBLIC_LIVEKIT_URL) return NextResponse.json({error:"LiveKit server settings are missing."},{status:503});
  let identity="", canPublish=false, canSubscribe=true;
  if(role==="admin"){
   if(!(await isAdmin())) return NextResponse.json({error:"Admin login required."},{status:401});
   identity="atm-admin";canPublish=true;
  } else if(role==="camera"){
   if(!/^cam-[1-8]$/.test(cameraId||"")) return NextResponse.json({error:"Invalid camera slot."},{status:400});
   identity=cameraId;canPublish=true;
  } else if(role==="viewer"){identity=`viewer-${crypto.randomUUID()}`;}
  else return NextResponse.json({error:"Invalid role."},{status:400});
  const at=new AccessToken(process.env.LIVEKIT_API_KEY,process.env.LIVEKIT_API_SECRET,{identity,ttl:"2h"});
  at.addGrant({roomJoin:true,room:"atm-live-main",canPublish,canSubscribe,canPublishData:false});
  return NextResponse.json({token:await at.toJwt(),serverUrl:process.env.NEXT_PUBLIC_LIVEKIT_URL});
 }catch{return NextResponse.json({error:"Could not create a camera session."},{status:500});}
}
