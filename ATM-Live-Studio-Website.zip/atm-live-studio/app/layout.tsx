import "./globals.css";
import type { Metadata } from "next";
export const metadata: Metadata = { title: "ATM LIVE STUDIO", description: "Professional multi-camera live production studio" };
export default function RootLayout({children}:{children:React.ReactNode}) { return <html lang="en"><body>{children}</body></html>; }